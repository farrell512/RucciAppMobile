package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;

public class grup2 extends AppCompatActivity {
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grup2);

        int a = getIntent().getIntExtra("index",0);
        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        String nama = arrListChat.get(a);
        String namabar = arrListChat.get(a).substring(arrListChat.get(a).indexOf("-")+1,nama.length());
        getSupportActionBar().setTitle(namabar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(grup2.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGrup){
            Intent moveActivity = new Intent(grup2.this,grup.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRiwayat){
            Intent moveActivity = new Intent(grup2.this,riwayat.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGabungKelas){
            Intent moveActivity = new Intent(grup2.this,gabungkelas.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKonsultasi){
            Intent moveActivity = new Intent(grup2.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuLatihan){
            Intent moveActivity = new Intent(grup2.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRating){
            Intent moveActivity = new Intent(grup2.this,rating.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        return true;
    }
}
