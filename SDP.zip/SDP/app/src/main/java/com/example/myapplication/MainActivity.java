package com.example.myapplication;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btnKlikDisini,btnMasuk;
    EditText inputEmail, inputPassword;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnKlikDisini = findViewById(R.id.btnKlikDisini);
        btnMasuk = findViewById(R.id.btnMasuk);
        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);

        getSupportActionBar().setTitle("RUCCI");

        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        btnKlikDisini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveActivity = new Intent(MainActivity.this,registerpage.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
        });
        btnMasuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(inputEmail.getText().toString() == "murid"){
                    Intent moveActivity = new Intent(MainActivity.this, beranda.class);
                    startActivity(moveActivity);
                }
                else if(inputPassword.getText().toString() == "guru"){
                    Intent moveActivity = new Intent(MainActivity.this, beranda_guru.class);
                    startActivity(moveActivity);
                }
            }
        });
    }
}
