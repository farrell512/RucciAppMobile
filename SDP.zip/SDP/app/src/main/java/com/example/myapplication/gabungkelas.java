package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class gabungkelas extends AppCompatActivity {
    Button btnGabungKelas;
    EditText inputKodeKelas;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gabungkelas);
        getSupportActionBar().setTitle("Gabung Kelas");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        btnGabungKelas = findViewById(R.id.btnGabungKelas);
        inputKodeKelas = findViewById(R.id.inputKodeKelas);

        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        btnGabungKelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int berhasil = 0;
                int index = 0;
                for (int i=0;i<arrKode.size();i++){
                    if(arrKode.get(i).equals(inputKodeKelas.getText().toString())){
                        berhasil = 1;
                    }
                }
                if(berhasil != 0){
                    Intent moveActivity = new Intent(gabungkelas.this, grup.class);
                    moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                    moveActivity.putStringArrayListExtra("arrKode",arrKode);
                    startActivity(moveActivity);
                    Toast.makeText(gabungkelas.this, "", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(gabungkelas.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGrup){
            Intent moveActivity = new Intent(gabungkelas.this,grup.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRiwayat){
            Intent moveActivity = new Intent(gabungkelas.this,riwayat.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGabungKelas){
            Intent moveActivity = new Intent(gabungkelas.this,gabungkelas.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKonsultasi){
            Intent moveActivity = new Intent(gabungkelas.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuLatihan){
            Intent moveActivity = new Intent(gabungkelas.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRating){
            Intent moveActivity = new Intent(gabungkelas.this,rating.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        return true;
    }
}
