package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class beranda_guru extends AppCompatActivity {
    Button btnLogout,btnBuatKelas;
    TextView tvNama;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda_guru);
        getSupportActionBar().setTitle("Beranda");


        if(getIntent().getExtras()!=null){
            arrListChat = getIntent().getStringArrayListExtra("arrListChat");
            arrKode = getIntent().getStringArrayListExtra("arrKode");
            //Toast.makeText(this, arrKode.get(0), Toast.LENGTH_SHORT).show();
        }
        btnLogout = findViewById(R.id.btnLogout);
        btnBuatKelas = findViewById(R.id.btnBuatKelas);
        tvNama = findViewById(R.id.tvNama);
        tvNama.setText(getIntent().getStringExtra("nama"));
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveActivity = new Intent(beranda_guru.this, MainActivity.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
        });
        btnBuatKelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveActivity = new Intent(beranda_guru.this, berandaguru2.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(beranda_guru.this,beranda_guru.class);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuChatting){
            Intent moveActivity = new Intent(beranda_guru.this,beranda_guru.class);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuBuatPertanyaan){
            Intent moveActivity = new Intent(beranda_guru.this,beranda_guru.class);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKelasPrivat){
            Intent moveActivity = new Intent(beranda_guru.this,beranda_guru.class);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuBonus){
            Intent moveActivity = new Intent(beranda_guru.this,beranda_guru.class);
            startActivity(moveActivity);
        }
        return true;
    }
}
