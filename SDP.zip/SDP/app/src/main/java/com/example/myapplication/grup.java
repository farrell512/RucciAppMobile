package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class grup extends AppCompatActivity {
    TextView tvBelumTersedia;
    ListView lvDaftarNama;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grup);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);


        tvBelumTersedia = findViewById(R.id.tvBelumTersedia);
        lvDaftarNama = findViewById(R.id.lvDaftarNama);
        getSupportActionBar().setTitle("Grup");
        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrListChat);
        getSupportActionBar().setTitle("Grup");

        String index = getIntent().getStringExtra("index");
        if(index == "0"){

        }
        else{
            tvBelumTersedia.setVisibility(View.INVISIBLE);
            lvDaftarNama.setVisibility(View.VISIBLE);
            lvDaftarNama.setAdapter(itemsAdapter);
        }

        lvDaftarNama.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent moveActivity = new Intent(grup.this,grup2.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                moveActivity.putExtra("index",i);
                startActivity(moveActivity);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(grup.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGrup){
            Intent moveActivity = new Intent(grup.this,grup.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRiwayat){
            Intent moveActivity = new Intent(grup.this,riwayat.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGabungKelas){
            Intent moveActivity = new Intent(grup.this,gabungkelas.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKonsultasi){
            Intent moveActivity = new Intent(grup.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuLatihan){
            Intent moveActivity = new Intent(grup.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRating){
            Intent moveActivity = new Intent(grup.this,rating.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        return true;
    }

}
