package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import java.util.ArrayList;

public class registerpage extends AppCompatActivity {
    Button btnBuatAkun;
    EditText editNama;
    RadioButton radioGuru,radioMurid;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerpage);

        getSupportActionBar().setTitle("RUCCI");

        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        btnBuatAkun = findViewById(R.id.btnBuatAkun);
        radioGuru = findViewById(R.id.radioGuru);
        radioMurid = findViewById(R.id.radioMurid);
        editNama = findViewById(R.id.editNama);

        btnBuatAkun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(radioGuru.isChecked()){
                Intent moveActivity = new Intent(registerpage.this,beranda_guru.class);
                moveActivity.putExtra("nama", editNama.getText().toString());
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
            else if(radioMurid.isChecked()){
                Intent moveActivity = new Intent(registerpage.this,beranda.class);
                moveActivity.putExtra("nama", editNama.getText().toString());
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
            }
        });

    }
}
