package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class riwayat extends AppCompatActivity {
    ListView listview;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat);

        getSupportActionBar().setTitle("Riwayat");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        listview = (ListView) findViewById(R.id.listview);

        ArrayList<String> arrRiwayat= new ArrayList<>();
        arrRiwayat.add("Bahasa Inggris - 90");
        arrRiwayat.add("Matematika - 85");
        arrRiwayat.add("Sejarah - 80");

        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1 ,arrRiwayat);
        listview.setAdapter(arrayAdapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(riwayat.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGrup){
            Intent moveActivity = new Intent(riwayat.this,grup.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRiwayat){
            Intent moveActivity = new Intent(riwayat.this,riwayat.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGabungKelas){
            Intent moveActivity = new Intent(riwayat.this,gabungkelas.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKonsultasi){
            Intent moveActivity = new Intent(riwayat.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuLatihan){
            Intent moveActivity = new Intent(riwayat.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRating){
            Intent moveActivity = new Intent(riwayat.this,rating.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        return true;
    }
}
