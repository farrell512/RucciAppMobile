package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class berandaguru3 extends AppCompatActivity {
    TextView tvKode;
    Button btnKembali;
    String kalimatkelas;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_berandaguru3);

        tvKode = findViewById(R.id.tvKode);
        btnKembali = findViewById(R.id.btnKembali);
        String kalimatkelas = getIntent().getStringExtra("kalimatkelas");

        tvKode.setText("Q81KG");
        if(arrListChat.size() != 0){
            arrListChat = getIntent().getStringArrayListExtra("arrListChat");
            arrKode = getIntent().getStringArrayListExtra("arrKode");
        }
        arrListChat.add(kalimatkelas);
        arrKode.add("Q81KG");

        btnKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveActivity = new Intent(berandaguru3.this,beranda_guru.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
        });
    }
    public void generateKode(){

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflate = getMenuInflater();
        inflate.inflate(R.menu.menuguru,menu);
        return true;
    }


}
