package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class beranda extends AppCompatActivity {
    Button btnLogout;
    TextView tvNama;
    ArrayList<String> arrListChat = new ArrayList<String>();
    ArrayList<String> arrKode = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        tvNama = findViewById(R.id.tvNama);
        tvNama.setText(getIntent().getStringExtra("nama"));
        btnLogout = findViewById(R.id.btnLogout);
        getSupportActionBar().setTitle("Beranda");

        arrListChat = getIntent().getStringArrayListExtra("arrListChat");
        arrKode = getIntent().getStringArrayListExtra("arrKode");

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveActivity = new Intent(beranda.this,MainActivity.class);
                moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
                moveActivity.putStringArrayListExtra("arrKode",arrKode);
                startActivity(moveActivity);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuBeranda){
            Intent moveActivity = new Intent(beranda.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGrup){
            Intent moveActivity = new Intent(beranda.this,grup.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRiwayat){
            Intent moveActivity = new Intent(beranda.this,riwayat.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuGabungKelas){
            Intent moveActivity = new Intent(beranda.this,gabungkelas.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuKonsultasi){
            Intent moveActivity = new Intent(beranda.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuLatihan){
            Intent moveActivity = new Intent(beranda.this,beranda.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        else if(item.getItemId() == R.id.menuRating){
            Intent moveActivity = new Intent(beranda.this,rating.class);
            moveActivity.putStringArrayListExtra("arrListChat",arrListChat);
            moveActivity.putStringArrayListExtra("arrKode",arrKode);
            startActivity(moveActivity);
        }
        return true;
    }
}
